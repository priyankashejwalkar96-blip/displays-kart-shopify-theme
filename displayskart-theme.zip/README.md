# Displays Kart – Shopify Online Store 2.0 theme

Converted from the `index.html` wireframe. Same design (Tailwind utilities + your custom CSS), now driven by real Shopify data and the theme editor.

## Install
1. Shopify admin → Online Store → Themes → Add theme → Upload zip → `displayskart-theme.zip`
2. Customize → set up the items below.

## Set up in admin
**Navigation (Content → Menus)**
- `main-menu`: HOME, SHOP (add child links = your collections → they become the mega-menu cards), APPLICATIONS (children optional), BLOG, CONTACT US
- `footer`: About us, Applications, Blog, FAQs, Contact us, Track your order
- `policies`: Privacy, Terms, Refund, Shipping

**Pages (Content → Pages)** – create and assign a template:
| Page handle | Template |
|---|---|
| contact | `page.contact` |
| applications | `page.applications` |
| wishlist | `page.wishlist` |
| about, faq, privacy-policy, terms, refund-policy, shipping-policy, track-order | `page` (default) |

**Home page** – every section is editable in the theme editor (hero, USP strip, intro, collection rows, showcase, CTA, who-we-serve, FAQ, mini lists). Pick a collection in each "Featured collection" section.

**Collections** – sidebar uses the menu chosen in the Collection page section. Filters (price, colour, size…) appear when you configure them in the free *Shopify Search & Discovery* app.

**Optional product metafields** (namespace `custom`): `highlights` (list of text), `material`, `dimensions` – shown on the product page.

## What replaced the prototype's JS mock data
| Prototype | Theme |
|---|---|
| `navigate()` SPA pages | Real Shopify templates/URLs |
| Mock `PRODUCTS` array | `collection.products`, `product` objects |
| Mock cart | Shopify AJAX cart (`/cart/add.js`) + `/cart` page |
| Filters/sort/pagination JS | Storefront filtering, `sort_by`, `{% paginate %}` |
| Contact `submitContact()` | `{% form 'contact' %}` (sends to store email) |
| Wishlist | Browser localStorage (per device) |

## Notes
- Tailwind is loaded from the Play CDN exactly like the wireframe, so the look is identical. For a production-speed build, compile Tailwind to a CSS file and remove the CDN `<script>` in `layout/theme.liquid` (the only remaining theme-check error is that parser-blocking script).
- Bulk 5% discount: create an automatic discount in Shopify (Discounts → Automatic); the cart shows it automatically.
- Checkout payments (Razorpay/UPI) are configured in Settings → Payments.
